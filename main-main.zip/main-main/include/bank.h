#ifndef bank_h
#define bank_h

#include <Zumo32U4.h>

extern float balance;


void updateBalance();

#endif